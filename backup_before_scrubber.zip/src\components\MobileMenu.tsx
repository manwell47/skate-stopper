import React, { useState } from "react";
import { LineData } from "../types";
import { Plus, Play, Trash2, MoreVertical, Edit2, ChevronLeft, Video } from "lucide-react";

interface Props {
  lines: LineData[];
  onPlay: (line: LineData) => void;
  onBack: () => void;
}

export default function MobileMenu({ lines, onPlay, onBack }: Props) {

  return (
    <div 
      className="flex-1 flex flex-col p-6 space-y-6 overflow-y-auto bg-zinc-950 relative font-sans pt-16"
    >
      <div className="absolute inset-0 vhs-overlay z-0" />

      <button onClick={onBack} className="absolute top-4 left-4 z-10 text-white hover:text-red-500 transition-colors p-2">
        <ChevronLeft className="w-8 h-8" strokeWidth={3} />
      </button>

      <div className="text-center space-y-2 relative z-10 w-full mt-4">
        <div className="flex justify-center mb-4">
          <Video className="w-16 h-16 text-white drop-shadow-[0_0_10px_rgba(255,255,255,0.5)]" strokeWidth={1.5} />
        </div>
        <h1 className="text-5xl font-display text-white drop-shadow-[2px_2px_0_rgba(255,0,0,0.8)] tracking-widest uppercase">
          TAPE<br/>STASH
        </h1>
        <p className="text-xl text-green-400 font-bold uppercase tracking-widest mt-2">YOUR CLIPS</p>
      </div>

      <div className="relative z-10 w-full space-y-4">
        {lines.length === 0 ? (
          <div className="border-4 border-white/20 p-8 text-center bg-black/50 w-full">
            <p className="text-2xl font-display text-white/50 tracking-widest uppercase">EMPTY STASH</p>
            <p className="text-sm font-sans font-bold text-white/40 mt-4 uppercase tracking-widest">GO BACK AND SEND A TAPE</p>
          </div>
        ) : (
          lines.map((line, i) => (
            <div key={i} className="bg-black/80 border-4 border-white p-4 flex flex-col justify-between shadow-[4px_4px_0_0_rgba(255,0,0,0.8)] relative group transform transition-transform hover:-translate-y-1">
              <div className="mb-4 space-y-1">
                <h3 className="text-3xl font-display text-white truncate uppercase tracking-widest drop-shadow-[1px_1px_0_rgba(255,0,0,0.8)]">{line.skater}</h3>
                <p className="text-sm font-sans font-bold text-green-400 truncate uppercase tracking-widest">{line.videoPart}</p>
                <p className="text-sm font-sans font-bold text-zinc-400 truncate uppercase tracking-widest">{line.lineName}</p>
                <div className="pt-2">
                  <span className="text-xs text-black font-sans font-bold bg-white px-2 py-1 uppercase tracking-widest">
                    {line.videoType === "Single" ? "SINGLE TRICK" : `${line.markers.length} TRICKS`}
                  </span>
                </div>
              </div>
              
              <button 
                onClick={(e) => { e.stopPropagation(); onPlay(line); }}
                className="w-full bg-red-600 text-white py-3 font-display text-2xl flex items-center justify-center gap-2 hover:bg-red-500 transition-colors uppercase tracking-widest shadow-[2px_2px_0_0_rgba(255,255,255,1)]"
              >
                <Play className="w-5 h-5 fill-current" /> PLAY TAPE
              </button>
            </div>
          ))
        )}
      </div>
    </div>
  );
}
