import React, { useState } from "react";
import { LineData } from "../types";
import { Trash2, MoreVertical, Edit2, ChevronLeft, Video, Download, Upload } from "lucide-react";

interface Props {
  lines: LineData[];
  onEdit: (index: number) => void;
  onDelete: (index: number) => void;
  onExportStash: () => void;
  onImportStash: () => void;
  onBack: () => void;
}

export default function MobileStash({ lines, onEdit, onDelete, onExportStash, onImportStash, onBack }: Props) {
  const [menuOpen, setMenuOpen] = useState<number | null>(null);

  return (
    <div 
      className="flex-1 flex flex-col p-6 space-y-6 overflow-y-auto bg-zinc-950 relative font-sans pt-16 pb-24"
      onClick={() => setMenuOpen(null)}
    >
      <div className="absolute inset-0 vhs-overlay z-0" />

      <button onClick={onBack} className="absolute top-4 left-4 z-10 text-white hover:text-red-500 transition-colors p-2">
        <ChevronLeft className="w-8 h-8" strokeWidth={3} />
      </button>

      <div className="text-center space-y-2 relative z-10 w-full mt-4">
        <div className="flex justify-center mb-4">
          <Video className="w-16 h-16 text-white drop-shadow-[0_0_10px_rgba(255,255,255,0.5)]" strokeWidth={1.5} />
        </div>
        <h1 className="text-5xl font-display text-white drop-shadow-[2px_2px_0_rgba(255,0,0,0.8)] tracking-widest uppercase">
          FOOTY<br/>STASH
        </h1>
        <p className="text-xl text-green-400 font-bold uppercase tracking-widest mt-2">MANAGEMENT</p>
      </div>

      <div className="relative z-10 w-full flex justify-between gap-2 mt-4">
        <button 
          onClick={(e) => { e.stopPropagation(); onExportStash(); }}
          className="flex-1 bg-black/80 border border-white/50 text-white font-sans font-bold text-xs py-2 uppercase tracking-wider hover:bg-white hover:text-black transition-colors flex items-center justify-center gap-2"
        >
          <Upload className="w-4 h-4" /> EXPORTAR
        </button>
        <button 
          onClick={(e) => { e.stopPropagation(); onImportStash(); }}
          className="flex-1 bg-black/80 border border-white/50 text-white font-sans font-bold text-xs py-2 uppercase tracking-wider hover:bg-white hover:text-black transition-colors flex items-center justify-center gap-2"
        >
          <Download className="w-4 h-4" /> IMPORTAR
        </button>
      </div>

      <div className="relative z-10 w-full space-y-4">
        {lines.length === 0 ? (
          <div className="border-4 border-white/20 p-8 text-center bg-black/50 w-full">
            <p className="text-2xl font-display text-white/50 tracking-widest uppercase">EMPTY STASH</p>
            <p className="text-sm font-sans font-bold text-white/40 mt-4 uppercase tracking-widest">NO HAY CLIPS GUARDADOS</p>
          </div>
        ) : (
          lines.map((line, i) => (
            <div key={i} className="bg-black/80 border-4 border-zinc-500 p-4 flex flex-col justify-between relative group transform transition-transform hover:-translate-y-1">
              <div className="absolute top-2 right-2 z-10">
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    setMenuOpen(menuOpen === i ? null : i);
                  }}
                  className="p-1 text-white hover:text-red-500 transition-colors"
                >
                  <MoreVertical className="w-6 h-6" />
                </button>

                {menuOpen === i && (
                  <div className="absolute right-0 mt-1 w-32 bg-zinc-900 border-2 border-white shadow-[4px_4px_0_0_rgba(255,0,0,0.8)] z-20 flex flex-col">
                    <button
                      onClick={(e) => { e.stopPropagation(); setMenuOpen(null); onEdit(i); }}
                      className="flex items-center gap-2 px-3 py-3 text-sm text-white hover:bg-zinc-800 text-left font-sans font-bold uppercase tracking-widest border-b-2 border-white/20"
                    >
                      <Edit2 className="w-4 h-4" /> EDIT
                    </button>
                    <button
                      onClick={(e) => { 
                        e.stopPropagation(); 
                        setMenuOpen(null); 
                        onDelete(i);
                      }}
                      className="flex items-center gap-2 px-3 py-3 text-sm text-red-500 hover:bg-zinc-800 text-left font-sans font-bold uppercase tracking-widest"
                    >
                      <Trash2 className="w-4 h-4" /> TRASH
                    </button>
                  </div>
                )}
              </div>
              
              <div className="pr-8 space-y-1">
                <h3 className="text-3xl font-display text-white truncate uppercase tracking-widest">{line.skater}</h3>
                <p className="text-sm font-sans font-bold text-green-400 truncate uppercase tracking-widest">{line.videoPart}</p>
                <p className="text-sm font-sans font-bold text-zinc-400 truncate uppercase tracking-widest">{line.lineName}</p>
                <div className="pt-2">
                  <span className="text-xs text-black font-sans font-bold bg-white px-2 py-1 uppercase tracking-widest">
                    {line.videoType === "Single" ? "SINGLE TRICK" : `${line.markers.length} TRICKS`}
                  </span>
                </div>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
}
